import { Routes, Route } from "react-router-dom";
import Dashboard from "../pages/Dashboard";
import Login from "../pages/Login";
import ProtectedRoute from "./ProtectedRoute";
import LicencePage from "../pages/LicencePage";
import SchoolCreatePage from "../pages/SchoolCreatePage";
import SchoolListPage from "../pages/SchoolListPage";
import LicenceCreatePage from "../pages/LicenceCreatePage";

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<Login />} />

      <Route
        path="/dashboard"
        element={
          <ProtectedRoute allowedRoles={["SUPER_ADMIN"]}>
            <Dashboard />
          </ProtectedRoute>
        }
      />
        <Route path="/licences" element={<LicencePage />} /> ✅
        <Route path="/schools" element={<SchoolListPage />} />
        <Route path="/schools/create" element={<SchoolCreatePage />} />
        <Route path="/licences/create" element={<LicenceCreatePage />} />

    </Routes>
  );
};

export default AppRoutes;