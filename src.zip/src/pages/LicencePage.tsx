// modules/licence/pages/LicencePage.tsx

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Plus } from "lucide-react";

import AppLayout from "../layouts/AppLayout";
import { useLicences } from "../hooks/useLicences";
import LicenceTable from "../components/LicenceTable";
import BulkUpload from "../components/BulkUpload";
import { useAuth } from "../hooks/useAuth";

const LicencePage = () => {
    const navigate = useNavigate();

    const { user } = useAuth();
    const [filters, setFilters] = useState({
        page: 1,
        search: "",
        status: "",
    });

    const { data, loading, fetchLicences } = useLicences(filters);

    return (
        <AppLayout>
            {/* 🔥 Header */}
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-xl font-semibold">Licences</h1>

                {/* + Icon Button */}
                <button
                    onClick={() => navigate("/licences/create")}
                    className="bg-green-600 text-white p-2 rounded-lg hover:bg-green-700 transition"
                >
                    <Plus size={18} />
                </button>
            </div>


            {/* 🔍 Filters */}
            <div className="bg-white p-4 rounded-xl shadow mb-4 flex gap-3 items-center">
                <input
                    placeholder="Search licence..."
                    className="border px-3 py-2 rounded-md text-sm w-60"
                    value={filters.search}
                    onChange={(e) =>
                        setFilters({ ...filters, search: e.target.value })
                    }
                />

                <select
                    className="border px-3 py-2 rounded-md text-sm"
                    value={filters.status}
                    onChange={(e) =>
                        setFilters({ ...filters, status: e.target.value })
                    }
                >
                    <option value="">All Status</option>
                    <option value="ACTIVE">Active</option>
                    <option value="DEACTIVATED">Inactive</option>
                </select>
            </div>

            {/* 📊 Table */}
            {loading ? (
                <div className="text-center py-10 text-gray-500">
                    Loading licences...
                </div>
            ) : (
                <LicenceTable
                    data={data}
                    refresh={fetchLicences}
                    user={user}
                />)}
        </AppLayout>
    );
};

export default LicencePage;