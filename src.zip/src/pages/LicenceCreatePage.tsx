import { useState } from "react";
import AppLayout from "../layouts/AppLayout";
import SingleCreate from "../components/SingleCreate";
import BulkUpload from "../components/BulkUpload";

const LicenceCreatePage = () => {
  const [mode, setMode] = useState<"single" | "bulk">("single");

  return (
    <AppLayout>
      <div className="max-w-2xl mx-auto">

        {/* Tabs */}
        <div className="flex gap-3 mb-6">
          <button
            onClick={() => setMode("single")}
            className={`px-4 py-2 rounded-lg ${
              mode === "single"
                ? "bg-green-600 text-white"
                : "bg-gray-200"
            }`}
          >
            Single Create
          </button>

          <button
            onClick={() => setMode("bulk")}
            className={`px-4 py-2 rounded-lg ${
              mode === "bulk"
                ? "bg-green-600 text-white"
                : "bg-gray-200"
            }`}
          >
            Bulk Upload
          </button>
        </div>

        {/* Content */}
        {mode === "single" ? <SingleCreate /> : <BulkUpload />}
      </div>
    </AppLayout>
  );
};

export default LicenceCreatePage;